
<form action="find.php" method="post">
Find: <input type="text" name="find" value='<?php echo $find; ?>'/><br><br>
Replace: <input type="text" name="replace" value='<?php echo $replace; ?>'/><br><br>
<input type="submit" value="Replace"/><br><br>
  </form>
<?php

$find =$_POST['find'] ;

$replace =$_POST['replace'];

//read the entire string
$myfile = fopen("eg.txt", 'r');
$str=file_get_contents("eg.txt");

//replace something in the file string - this is a VERY simple example
$str=str_replace("$find", "$replace",$str);

//write the entire string
file_put_contents('eg.txt', $str);

fclose($myfile);
/*
$file = fopen("eg.txt","w+");

// exclusive lock
if (flock($file,LOCK_EX))
  {
  fwrite($file,"Write something");
  // release lock
  flock($file,LOCK_UN);
  }
else
  {
  echo "Error locking file!";
  }

fclose($file);
*/



?>